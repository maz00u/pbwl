<h2>Login</h2>

<div class="info">Selamat datang, <strong>di Website PT PLN</strong></div>

<form action="<?php echo URL; ?>/Dashboard/index" method="post">
    <p>Username</p>
    <input type="text">
    <p>Password</p>
    <input type="password">
    <p><input type="submit" value="Login"></p>
</form>
