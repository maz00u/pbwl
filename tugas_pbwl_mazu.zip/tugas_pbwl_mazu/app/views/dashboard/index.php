<h2>Dashboard</h2>

<div class="info">Selamat datang, <strong>di Website PT PLN</strong></div>
<br>

<p>Perusahaan Listrik Negara (PLN) sebagai salah satu BUMN yang bergerak di bidang energi kelistrikan merupakan tulang punggung penyediaan energi nasional. 
<br>PT PLN (Persero) menetapkan sejumlah strategi bagi keberlanjutan penyediaan dan transisi sumber energi baru.</p>

<h4>Visi</h4>
<p>Menjadi Perusahaan Listrik Terkemuka se-Asia Tenggara dan #1 Pilihan Pelanggan untuk Solusi Energi.

<h4>Misi</h4>
<p>Menjalankan bisnis kelistrikan dan bidang lain yang terkait, berorientasi pada kepuasan pelanggan, anggota perusahaan dan pemegang saham.
<br>Menjadikan tenaga listrik sebagai media untuk meningkatkan kualitas kehidupan masyarakat.
<br>Mengupayakan agar tenaga listrik menjadi pendorong kegiatan ekonomi.
<br>Menjalankan kegiatan usaha yang berwawasan lingkungan.
